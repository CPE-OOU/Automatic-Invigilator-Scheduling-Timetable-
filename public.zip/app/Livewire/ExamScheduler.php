<?php

namespace App\Livewire;

use Livewire\Component;

class ExamScheduler extends Component
{
    public function render()
    {
        return view('livewire.exam-scheduler');
    }
}
